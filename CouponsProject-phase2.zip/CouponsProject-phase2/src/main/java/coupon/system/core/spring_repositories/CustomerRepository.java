package coupon.system.core.spring_repositories;

import coupon.system.core.entity_beans.Company;
import coupon.system.core.entity_beans.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface CustomerRepository extends JpaRepository<Customer,Integer> {

    public Customer findByEmailAndPassword(String email, String password);

    public boolean existsByEmail(String email);
}
