package coupon.system.core.spring_repositories;

import coupon.system.core.entity_beans.Company;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.persistence.OrderBy;
import java.util.List;

public interface CompanyRepository extends JpaRepository<Company,Integer> {

    public Company findByEmailAndPassword(String email,String password);

    public boolean existsByEmail(String email);

    public boolean existsByName(String name);


    @Override
    @OrderBy("name ASC")
    public List<Company> findAll();
}
