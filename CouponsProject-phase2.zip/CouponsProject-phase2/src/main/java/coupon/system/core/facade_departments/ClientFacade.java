package coupon.system.core.facade_departments;


import coupon.system.core.spring_repositories.CompanyRepository;
import coupon.system.core.spring_repositories.CouponRepository;
import coupon.system.core.spring_repositories.CustomerRepository;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.PersistenceContext;

public abstract class ClientFacade {
    @Autowired
    protected CompanyRepository companyRepository;
    @Autowired
    protected CustomerRepository customerRepository;
    @Autowired
    protected CouponRepository couponRepository;

    //TODO maybe change the "findbyid" to findByid().orElse(null);

    /**
     * this method is used to access to the relevant information from the database
     * depending on the Client type.
     * also initiate the ClientId if relevant
     * @param email Client Email
     * @param password Client password
     * @return true if access is granted and false if access denied
     */
    public abstract boolean login(String email, String password);
}
