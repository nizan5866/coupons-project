package coupon.system.core.entity_beans;


import javax.persistence.Entity;

public enum Category {
    COMPUTERS,
    SMARTPHONES,
    SOFTWARE,
    CLOUD_STORAGE
}


