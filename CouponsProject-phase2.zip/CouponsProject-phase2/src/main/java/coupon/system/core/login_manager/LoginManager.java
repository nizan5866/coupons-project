package coupon.system.core.login_manager;

import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.facade_departments.AdminFacade;
import coupon.system.core.facade_departments.ClientFacade;
import coupon.system.core.facade_departments.CompanyFacade;
import coupon.system.core.facade_departments.CustomerFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class LoginManager {
    @Autowired
    ApplicationContext ctx;


    public ClientFacade login(String email, String password, ClientType clientType) throws CouponSystemException {
        ClientFacade clientFacade;
        switch (clientType) {
            case ADMINISTRATOR -> {
                clientFacade = ctx.getBean(AdminFacade.class);
                if (clientFacade.login(email, password)) {
                    return clientFacade;
                } else {
                    return null;
                }
            }
            case COMPANY -> {
                clientFacade = ctx.getBean(CompanyFacade.class);
                if (clientFacade.login(email, password)) {
                    return clientFacade;
                } else {
                    return null;
                }
            }
            default -> {
                clientFacade = ctx.getBean(CustomerFacade.class);
                if (clientFacade.login(email, password)) {
                    return clientFacade;
                } else {
                    return null;
                }

            }
        }
    }
}


