package coupon.system.core.coupons_exterminator2;

import coupon.system.core.spring_repositories.CouponRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@Transactional
public class ExtraHelper {

    /**
     * i have to use this extra helper so i can use the Thread that uses the static method of class (the executive
     * service thingy)
     * @param couponRepository
     */
    public void delete(CouponRepository couponRepository){
        couponRepository.deleteAllByEndDateBefore(LocalDate.now());
    }
}
