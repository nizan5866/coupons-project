package coupon.system.core.controllers;

import coupon.system.core.entity_beans.Category;
import coupon.system.core.entity_beans.Company;
import coupon.system.core.entity_beans.Coupon;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.facade_departments.CompanyFacade;
import coupon.system.core.login_manager.LoginManager;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/company")
public class CompanyController extends ClientController{

    LoginManager loginManager;
    CompanyFacade companyFacade;

    public CompanyController(CompanyFacade companyFacade) {
        this.companyFacade = companyFacade;
        companyFacade.setCompanyId(2);
    }

    @PostMapping("/add-coupon")
    private void addCoupon(@RequestBody Coupon coupon) throws CouponSystemException {
        companyFacade.addCoupon(coupon);
    }

    @PutMapping("/update-coupon")
    private void updateCoupon(@RequestBody Coupon coupon) throws CouponSystemException{
        companyFacade.updateCoupon(coupon);
    }

    @DeleteMapping("/delete-coupon{couponId}")
    private void deleteCoupon(@PathVariable int couponId) throws CouponSystemException {
        companyFacade.deleteCoupon(couponId);
    }

    @GetMapping("/get-all-coupons")
    private List<Coupon> getAllCoupons() throws CouponSystemException {
        return companyFacade.getAllCoupons();
    }

    @GetMapping("/get-all-coupons-by-category")
    private List<Coupon> getAllCouponsByCategory(@RequestParam Category category) throws CouponSystemException {
        return companyFacade.getAllCouponsByCategory(category);
    }

    @GetMapping("/get-all-coupons-by-max-price")
    private List<Coupon> getAllCouponsByMaxPrice(@RequestParam double maxPrice) throws CouponSystemException {
        return companyFacade.getAllCouponsByMaxPrice(maxPrice);
    }

    @GetMapping("/get-company-details")
    public Company getCompanyDetails() throws CouponSystemException {
        return companyFacade.getCompanyDetails();
    }

    @ExceptionHandler
    private String exceptionHandler(CouponSystemException e){
        return e.getMessage();
    }


    @Override
    public boolean login(String email, String password) {
        return false;
    }
}
