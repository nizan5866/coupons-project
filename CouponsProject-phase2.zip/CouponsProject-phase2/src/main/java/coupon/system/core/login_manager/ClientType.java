package coupon.system.core.login_manager;

public enum ClientType {

    ADMINISTRATOR,
    COMPANY,
    CUSTOMER;
}
