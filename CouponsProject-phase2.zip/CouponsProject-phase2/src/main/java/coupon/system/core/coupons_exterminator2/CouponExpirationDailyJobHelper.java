package coupon.system.core.coupons_exterminator2;

import coupon.system.core.spring_repositories.CouponRepository;


class CouponExpirationDailyJobHelper {
    static CouponRepository couponRepository;
    static ExtraHelper extraHelper;


    /**
     * i have to do it like that so i can use the executive Thread thingy
     */
    public static void deleteCouponsExp() {
        extraHelper.delete(couponRepository);
    }

}
