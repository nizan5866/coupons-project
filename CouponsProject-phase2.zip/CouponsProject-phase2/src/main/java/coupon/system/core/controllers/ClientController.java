package coupon.system.core.controllers;

public abstract class ClientController {

    abstract public boolean login(String email, String password);
}
