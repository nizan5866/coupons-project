package coupon.system.core.controllers;

import coupon.system.core.entity_beans.Company;
import coupon.system.core.entity_beans.Customer;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.facade_departments.AdminFacade;
import coupon.system.core.login_manager.LoginManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController extends ClientController{

    private LoginManager loginManager;
    //TODO need to delete the autowire and do it with login and tokens
    private final AdminFacade adminFacade;

    public AdminController(AdminFacade adminFacade) {
        this.adminFacade = adminFacade;
    }

    @PostMapping(path = "/add-company")
    private void addCompany(@RequestBody Company company) throws CouponSystemException {
        adminFacade.addCompany(company);
    }



    @PutMapping(path = "update-company")
    private void updateCompany(@RequestBody Company company) throws CouponSystemException {
        adminFacade.updateCompany(company);
    }

    @DeleteMapping("/delete-company{companyId}")
    private void deleteCompany(@PathVariable int companyId) throws CouponSystemException {
        adminFacade.deleteCompany(companyId);
    }

    @GetMapping(
            path = "/get-all-companies",
            produces = {"application/json", "application/xml"}
    )
    private List<Company> getAllCompanies() throws CouponSystemException {
        return adminFacade.getAllCompanies();
    }

    @GetMapping(
            path = "/get-one-company{companyId}",
            produces = {"application/json", "application/xml"}
    )
    private Company getOneCompany(@PathVariable int companyId) throws CouponSystemException {
        return adminFacade.getOneCompany(companyId);
    }

    @PostMapping("/add-one-customer")
    private void addCustomer(@RequestBody Customer customer) throws CouponSystemException {
        adminFacade.addCustomer(customer);
    }

    @PutMapping("/update-customer")
    private void updateCustomer(@RequestBody Customer customer) throws CouponSystemException {
        adminFacade.updateCustomer(customer);
    }

    @DeleteMapping("/delete-customer{customerId}")
    private void deleteCustomer(@PathVariable int customerId) throws CouponSystemException {
        adminFacade.deleteCustomer(customerId);
    }

    @GetMapping("/get-all-customers")
    private List<Customer> getAllCustomers() throws CouponSystemException {
        return adminFacade.getAllCustomers();
    }

    @GetMapping("/get-one-customer{customerId}")
    private Customer getOneCustomer(@PathVariable int customerId) throws CouponSystemException {
        return adminFacade.getOneCustomer(customerId);
    }


    @ExceptionHandler
    private String exceptionHandler(CouponSystemException e){
        return e.getMessage();
    }


    @Override
    public boolean login(String email, String password) {
        return false;
    }
}
