package coupon.system.core.controllers;

import coupon.system.core.entity_beans.Category;
import coupon.system.core.entity_beans.Coupon;
import coupon.system.core.entity_beans.Customer;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.facade_departments.CustomerFacade;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
public class CustomerController extends ClientController{

    CustomerFacade customerFacade;

    public CustomerController(CustomerFacade customerFacade) {
        this.customerFacade = customerFacade;
        customerFacade.setCustomerId(4);
    }

    @PutMapping("/purchase-coupon")
    public void purchaseCoupon(@RequestBody Coupon coupon) throws CouponSystemException {
        customerFacade.purchaseCoupon(coupon);
    }

    @GetMapping("/get-all-coupons")
    public List<Coupon> getAllCoupons() throws CouponSystemException {
        return customerFacade.getAllCoupons();
    }

    @GetMapping("/get-all-coupons-by-category")
    public List<Coupon> getAllCouponsByCategory(@RequestParam Category category) throws CouponSystemException{
        return customerFacade.getAllCouponsByCategory(category);
    }

    @GetMapping("get-all-coupons-by-max-price")
    public List<Coupon> getAllCouponsByMaxPrice(@RequestParam double maxPrice) throws CouponSystemException {
        return customerFacade.getAllCouponsByMaxPrice(maxPrice);
    }

    @GetMapping("get-customer-details")
    public Customer getCustomerDetails() throws CouponSystemException {
        return customerFacade.getCustomerDetails();
    }

    @ExceptionHandler
    private String exceptionHandler(CouponSystemException e){
        return e.getMessage();
    }

    @Override
    public boolean login(String email, String password) {
        return false;
    }
}
