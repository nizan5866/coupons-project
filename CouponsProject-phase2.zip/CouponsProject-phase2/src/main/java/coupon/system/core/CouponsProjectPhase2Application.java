package coupon.system.core;

import coupon.system.core.test.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author nizan5866
 */
@SpringBootApplication
@EnableSwagger2
public class CouponsProjectPhase2Application {


    public static void main(String[] args) {

        try (ConfigurableApplicationContext ctx = SpringApplication.run(CouponsProjectPhase2Application.class, args)) {
            Test test = ctx.getBean(Test.class);
            test.testAll();
        }
        SpringApplication.run(CouponsProjectPhase2Application.class, args);
    }

}