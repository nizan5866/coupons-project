package coupon.system.core.test;

import coupon.system.core.DAOdepartments.CompaniesDB_DAO;
import coupon.system.core.DAOdepartments.CouponsDB_DAO;
import coupon.system.core.DAOdepartments.CustomersDB_DAO;
import coupon.system.core.FACADEdepartments.AdminFacade;
import coupon.system.core.FACADEdepartments.CompanyFacade;
import coupon.system.core.FACADEdepartments.CustomerFacade;
import coupon.system.core.LoginManager.ClientType;
import coupon.system.core.LoginManager.LoginManager;
import coupon.system.core.coupons_exterminator.CouponExpirationDailyJob;
import coupon.system.core.db.ConnectionPool;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Category;
import coupon.system.core.javaBeans.Company;
import coupon.system.core.javaBeans.Coupon;
import coupon.system.core.javaBeans.Customer;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class Test {


    /**
     * if there is a problem with the prints, and the eclipse doesnt know how to
     * interpret the colors in the System.out.println, you can just change it down here
     * to " " or to a string the eclipse know how to handle.
     * this is very comfortable to see if a test passed or not
     * sorry for the inconvenient.
     */
    public static class COLORS {
        public static final String ANSI_RESET = "\u001B[0m";
        public static final String ANSI_RED = "\u001B[31m";
        public static final String ANSI_GREEN = "\u001B[32m";
        public static final String ANSI_YELLOW = "\u001B[33m";
    }

    /**
     * i have built this function using inside functions for testing each Facade.
     * in each testFacade method there are A LOT of testing FOR EACH method inside the Facade.
     * it's also initialize the sql tables each time a Facade testing method starts.
     * this is because i wanted a fresh test each time. for example, if i am deleting one of the companies
     * in the admin test facade it would have create problems for testing things on this company
     * in the CompanyFacade.
     *
     * of course, it's also initialize the daily job.
     *
     */
    public static void testAll(){
        try {
            CouponExpirationDailyJob couponExpirationDailyJob = new CouponExpirationDailyJob();
            couponExpirationDailyJob.start();
            testAdminFacade();
            testCompanyFacade();
            testCustomerFacade();
            couponExpirationDailyJob.stopJob();
            ConnectionPool.getInstance().closeAllConnections();
        } catch (CouponSystemException e) {
            System.out.println(e.getMessage());
        }
    }


    /**
     * private method for the testAll method. this method is for testing the CompanyFacade
     * @throws CouponSystemException for various reasons
     */
    private static void testCompanyFacade() throws CouponSystemException {
        RestartSQL.restartSQL();
        CompanyFacade cF = (CompanyFacade) LoginManager.getInstance()
                .login(RestartSQL.COMPANY1.getEmail(),RestartSQL.COMPANY1.getPassword(), ClientType.COMPANY);
        System.out.println(COLORS.ANSI_YELLOW + "test for class CompanyFacade" + COLORS.ANSI_RESET);

        System.out.println("======================test login METHOD: ===========================");
        System.out.print("test 1: (legit login) :");
        try {
            if (cF.login("apple@gmail.com", "1234")) {
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            }
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2 : (wrong password) :");
        try {
            if (cF.login("apple@gmail.com", "4321")) {
                System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
            } else {
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            }
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        }

        System.out.print("test 3 : (trying after changed password) :");
        try {
            CompaniesDB_DAO companiesDB_dao = new CompaniesDB_DAO();
            companiesDB_dao.updateCompany(new Company(1, "Apple", "apple@gmail.com", "4321"));
            if (cF.login("apple@gmail.com", "4321")) {
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            }
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("==============================================");

        System.out.println("======test for addCoupon METHOD ===============");
        System.out.print("test 1: (add legit Coupon)  :");
        try {
            cF.addCoupon(new Coupon(100, 1, Category.ELECTRICITY, "20% off Ipads", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 100, "@@@"));
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 2: (add coupon with same Title for the same company) :");
        try {
            cF.addCoupon(new Coupon(100, 1, Category.FOOD, "20% off Ipads", "get 20% discountartphones", LocalDate.parse("2021-01-02"), LocalDate.parse("2022-11-30"), 4, 99, "@@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage() + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 3: (add coupon with endDate before Today) :");
        try {
            cF.addCoupon(new Coupon(100, 1, Category.FOOD, "20% off Ipadsss", "get 20% discountartphones", LocalDate.parse("2021-01-02"), LocalDate.parse("2021-06-01"), 4, 99, "@@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 4: (add coupon with endDate before startDate:");
        try {
            cF.addCoupon(new Coupon(100, 1, Category.FOOD, "20% off Ipadsss", "get 20% discountartphones", LocalDate.parse("2021-10-02"), LocalDate.parse("2021-09-01"), 4, 99, "@@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.println("============================================================");
        System.out.println("=========test updateCoupon METHOD===========================");
        System.out.print("test1: (legitimate update) :");
        try {
            Coupon COUPON1 = new Coupon(1, 1, Category.FOOD, "20% off smartphonesss", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 3000, 100, "@@@");
            cF.updateCoupon(COUPON1);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()   + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test2: (update coupon that doesnt belong to company) :");
        try {
            Coupon COUPON1 = new Coupon(1, 2, Category.FOOD, "20% off smartphonesss", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 3000, 100, "@@@");
            cF.updateCoupon(COUPON1);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 3: (update title to already exist title on other coupon of the same company) :");
        try {
            Coupon COUPON1 = new Coupon(1, 1, Category.FOOD, "20% off computers", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 3000, 100, "@@@");
            cF.updateCoupon(COUPON1);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage() + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 4: (update title to title exist in other company) :");
        try {
            Coupon COUPON1 = new Coupon(1, 1, Category.FOOD, "ONLY EXCEL", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 3000, 100, "@@@");
            cF.updateCoupon(COUPON1);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 5: (update coupon end date before start date) :");
        try {
            Coupon COUPON1 = new Coupon(1, 1, Category.FOOD, "get 20% of smartphones ", "get 20% discount on smartphones", LocalDate.parse("2023-01-01"), LocalDate.parse("2022-12-31"), 3000, 100, "@@@");
            cF.updateCoupon(COUPON1);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage() + "]" + COLORS.ANSI_RESET);
        }


        System.out.println("============test deleteCoupon METHOD====================");
        System.out.print("test 1: (legit delete) :");
        try {
            cF.deleteCoupon(2);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 2: (deleting coupon doesnt belong to this company) :");
        try {
            cF.deleteCoupon(7);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("============tes getAllCoupons METHOD=====================");
        System.out.print("test 1: (legit)   :");
        try {
            cF.getAllCoupons();
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 2: (if there is no coupons)");
        cF.deleteCoupon(1);
        cF.deleteCoupon(3);
        cF.deleteCoupon(26);
        try {
            cF.getAllCoupons();
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("=========test getAllCouponsByCategory====================");
        System.out.print("test1: (legit)        :");
        CompanyFacade cF2 =(CompanyFacade) LoginManager.getInstance().login(RestartSQL.COMPANY2.getEmail(),
                RestartSQL.COMPANY2.getPassword(),ClientType.COMPANY);
        try {
            if (cF2.getAllCouponsByCategory(Category.ELECTRICITY).size() == 3) {
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            } else {
                throw new CouponSystemException();
            }
        } catch (CouponSystemException e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test2: (suppose to be empty) :");
        cF2.deleteCoupon(4);
        cF2.deleteCoupon(6);
        cF2.deleteCoupon(7);
        try {
            cF2.getAllCouponsByCategory(Category.ELECTRICITY);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()   + "]" + COLORS.ANSI_RESET);
        }
        CompanyFacade cF4 = (CompanyFacade) LoginManager.getInstance().login
                (RestartSQL.COMPANY4.getEmail(),RestartSQL.COMPANY4.getPassword(),ClientType.COMPANY);
        System.out.println("============testing get all coupons by max price method===============");
        System.out.print("test1 : (legit) :");
        try {
            if (cF4.getAllCouponsByMaxPrice(90).size() == 2) {
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            } else {
                throw new CouponSystemException();
            }
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 2 : (null)   :");
        try {
            cF4.getAllCouponsByMaxPrice(1);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test getCompanyDetails METHOD:");
        try {
            Company company = cF4.getCompanyDetails();
            System.out.println(COLORS.ANSI_GREEN + "success" +company + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println(COLORS.ANSI_YELLOW + "test for class CompanyFacade has ended" + COLORS.ANSI_RESET);
    }

    //==================================================================================================================

    /**
     * this method is for the use of the method testAll and it contains alot
     * of tests for th CustomerFacade
     * @throws CouponSystemException can throw for varies reasons
     */
    private static void testCustomerFacade() throws CouponSystemException {
        RestartSQL.restartSQL();
        System.out.println(COLORS.ANSI_YELLOW + "test for class CustomerFacade" + COLORS.ANSI_RESET);
        CustomerFacade customerFacade1 = (CustomerFacade) LoginManager.getInstance().login
                (RestartSQL.CUSTOMER1.getEmail(),RestartSQL.CUSTOMER1.getPassword(),ClientType.CUSTOMER);
        CustomersDB_DAO customersDBDao = new CustomersDB_DAO();
        Customer c1 = customersDBDao.getOneCustomer(1);
        System.out.print("testing login METHOD: ");
        if (customerFacade1.login(c1.getEmail(), "1234")) {
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } else {
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }
        System.out.println("===============testing Purchase Coupon Method===============");
        System.out.print("test1: (legit)   :");
        try {
            customerFacade1.purchaseCoupon(new Coupon(12, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@"));
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test2: (coupon already purchased) :");
        try {
            customerFacade1.purchaseCoupon(new Coupon(12, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test3: (coupon is not exist) : ");
        try{
            customerFacade1.purchaseCoupon(new Coupon(50, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test4: (coupon is out of amount) :");
        try{
            CouponsDB_DAO couponsDB_dao = new CouponsDB_DAO();
            couponsDB_dao.updateCoupon(new Coupon(24, 9, Category.ELECTRICITY, "20% off smartphones", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 0, 74.76, "@@@"));
            customerFacade1.purchaseCoupon(new Coupon(24, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()   + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test5: (Coupon start date has not yet come) :");
        try{
            CouponsDB_DAO couponsDB_dao = new CouponsDB_DAO();
            couponsDB_dao.updateCoupon(new Coupon(24, 9, Category.ELECTRICITY, "20% off smartphones", "get 20% discount on smartphones", LocalDate.parse("2021-09-01"), LocalDate.parse("2022-12-31"), 5, 74.76, "@@@"));
            customerFacade1.purchaseCoupon(new Coupon(24, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test6: (Coupon expiration date has passed) :");
        try{
            CouponsDB_DAO couponsDB_dao = new CouponsDB_DAO();
            couponsDB_dao.updateCoupon(new Coupon(24, 9, Category.ELECTRICITY, "20% off smartphones", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2021-03-01"), 5, 74.76, "@@@"));
            customerFacade1.purchaseCoupon(new Coupon(24, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("========test getAllCoupons METHOD==============");
        System.out.print("test1: (legit) :");
        Customer c9 = RestartSQL.CUSTOMER9;
        CustomerFacade cF9 = (CustomerFacade) LoginManager.getInstance().login
                (c9.getEmail(),c9.getPassword(),ClientType.CUSTOMER);
        Customer c2 = RestartSQL.CUSTOMER2;
        CustomerFacade cF2 = (CustomerFacade) LoginManager.getInstance().login
                (c2.getEmail(),c2.getPassword(),ClientType.CUSTOMER);
        try{
            List<Coupon> coupons = cF9.getAllCoupons();
            if(coupons.size() == 9) {
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            }else{
                throw new CouponSystemException();
            }
        }catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test2: (not any coupons) :");
        try{
            CouponsDB_DAO couponsDB_dao = new CouponsDB_DAO();
            couponsDB_dao.deleteCouponPurchase(4,13);
            Customer c4 = RestartSQL.CUSTOMER4;
            CustomerFacade cF4 = (CustomerFacade) LoginManager.getInstance().login
                    (c4.getEmail(),c4.getPassword(),ClientType.CUSTOMER);
            cF4.getAllCoupons();
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("========test getAllCouponsByCategory METHOD=========");
        System.out.print("test1: (legit) :");
        try{
            List<Coupon> coupons12 = cF2.getAllCouponsByCategory(Category.ELECTRICITY);
            if(coupons12.size() == 2){
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            }else{
                throw new CouponSystemException();
            }
        }catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test2: (not any) :");
        try{
            List<Coupon> coupons12 = cF2.getAllCouponsByCategory(Category.FOOD);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("===========test getAllCoupons getAllCouponsOfCustomerByMaxPrice METHOD =======");
        System.out.print("test1 : (legit) :");
        try{
            List<Coupon> coupons = cF9.getAllCouponsByMaxPrice(100);
            if(coupons.size() == 4){
                System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
            }else{
                throw new CouponSystemException();
            }
        }catch (Exception e){
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test2 : (not any coupons) :");
        try{
            List<Coupon> coupons = cF9.getAllCouponsByMaxPrice(1);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  +"]" + COLORS.ANSI_RESET);
        }

        System.out.print("test CustomerDetails METHOD: ");
        try{
            cF9.getCustomerDetails();
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        }catch (Exception e){
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }


        System.out.println(COLORS.ANSI_YELLOW + "test for class CustomerFacade has ended" + COLORS.ANSI_RESET);



    }

    //==================================================================================================================

    /**
     * this method if a private method for the use of the testAll method of this class.
     * this method tests the methods of the class AdminFacade
     * @throws CouponSystemException for various reasons
     */
    private static void testAdminFacade() throws CouponSystemException {
        RestartSQL.restartSQL();
        System.out.println(COLORS.ANSI_YELLOW + "test for class AdminFacade" + COLORS.ANSI_RESET);
        AdminFacade aF = (AdminFacade) LoginManager.getInstance().login
                ("admin@admin.com","admin",ClientType.ADMINISTRATOR);
        System.out.print("testing login METHOD: ");
        try {
            aF.login("admin@admin.com", "admin");
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.println("==========testing addNewCompany METHOD: ==========");
        System.out.print("test 1: (adding legit company) :");
        try {
            aF.addNewCompany(new Company(11, "TheNorthFace", "thenorthface@gmail.com", "1234"));
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (adding company with the same name) :");
        try {
            aF.addNewCompany(new Company(12, "TheNorthFace", "123@gmail.com", "1234"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" +e.getMessage() + " "+ e.getCause().getMessage() + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 3: (adding company with the same Email) :");
        try {
            aF.addNewCompany(new Company(13, "TheNorthFacee", "thenorthface@gmail.com", "1234"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 4: (adding company with the same Email and the same Name): ");
        try {
            aF.addNewCompany(new Company(14, "TheNorthFace", "thenorthface@gmail.com", "1234"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("==============================================\n");

        System.out.println("=============test update company METHOD:  ================");
        System.out.print("test 1: (updating legit) :");
        try {
            aF.updateCompany(new Company(1, "Apple", "newemailforApple@gmail.com", "909090"));
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (updating by changing name):");
        try {
            aF.updateCompany(new Company(1, "Applee", "newemailforApple@gmail.com", "909090"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 3: (updating with no valid ID):");
        try {
            aF.updateCompany(new Company(14, "Appleee", "newemailforApple1@gmail.com", "909090"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("==============================================\n");
        System.out.println("==========test deleteCompany METHOD============");
        System.out.print("test 1: (deleting legit) :");
        try {
            aF.deleteCompany(2);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (deleting legit) :");
        try {
            aF.deleteCompany(3);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 3: (deleting legit) :");
        try {
            aF.deleteCompany(4);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + Arrays.toString(e.getStackTrace()) + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 4 (deleting not legit) :");
        try {
            aF.deleteCompany(4);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }


        System.out.print("test getOneCompany Method: ");
        try {
            aF.getOneCompany(5);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + Arrays.toString(e.getStackTrace()) + "]" + COLORS.ANSI_RESET);
        }

        System.out.println("================test addNewClient Method : ===============");
        System.out.print("test 1: (adding a legit customer) :");
        try {
            aF.addNewCustomer(new Customer(11, "Shmuel", "cohen", "shmuelcohen@gmail.com", "1234"));
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (creating customer with the same Email) :");
        try {
            aF.addNewCustomer(new Customer(12, "Shmusdfel", "cohsdfen", "shmuelcohen@gmail.com", "12345"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.println("==================testing updateCustomerMethod=================");
        System.out.print("test 1: (updating legit) :");
        try {
            aF.updateCustomer(new Customer(1, "Avrahamm", "Cohenn", "avrahamcohenn@gmail.com", "12345"));
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.print("test 2: (updating not legit) :");
        try {
            aF.updateCustomer(new Customer(35, "Avrahamm", "Cohenn", "avrahamcohenn@gmail.com", "12345"));
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("=======================================================");

        System.out.println("===========test deleteCustomer METHOD===================");

        System.out.print("test 1: (delete legit) :");
        try {
            aF.deleteCustomer(1);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (not legit delete) :");
        try {
            aF.deleteCustomer(35);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + "]" + COLORS.ANSI_RESET);
        }
        System.out.println("=======================================================");

        System.out.println("=============test getOneCustomer METHOD=====================");
        System.out.print("test 1 : (get one customer legit) :");
        try {
            aF.getOneCustomer(7);
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2 : (get one customer that doesnt exist) :");
        try {
            aF.getOneCustomer(30);
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }


        System.out.println("======test getAllCustomers METHOD========================");
        System.out.print("test 1 (get all customers legit) :");
        try {
            aF.getAllCustomer();
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (get all customers when there aren't any customers) : ");
        for (int i = 0; i <= 12; i++) {
            try {
                aF.deleteCustomer(i);
            } catch (Exception e) {
            }
        }
        try {
            System.out.println(aF.getAllCustomer());
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }


        System.out.println("====================test getAllCompanies METHOD: ============================");
        System.out.print("test 1: (get all companies when there is companies)   :");
        try {
            aF.getAllCompanies();
            System.out.println(COLORS.ANSI_GREEN + "success" + COLORS.ANSI_RESET);
        } catch (
                Exception e) {
            System.out.println(COLORS.ANSI_RED + "test failed [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }

        System.out.print("test 2: (get all companies when there isn't any companies) : ");
        for (
                int i = 0;
                i <= 20; i++) {
            try {
                aF.deleteCompany(i);
            } catch (Exception e) {
            }
        }
        try {
            System.out.println(aF.getAllCompanies());
            System.out.println(COLORS.ANSI_RED + "test failed" + COLORS.ANSI_RESET);
        } catch (
                Exception e) {
            System.out.println(COLORS.ANSI_GREEN + "success [" + e.getMessage() + " "+ e.getCause().getMessage()  + "]" + COLORS.ANSI_RESET);
        }
        System.out.println(COLORS.ANSI_YELLOW + "test for class CompanyFacade has ended" + COLORS.ANSI_RESET);

    }
}