package coupon.system.core.test;

import coupon.system.core.DAOdepartments.CompaniesDB_DAO;
import coupon.system.core.DAOdepartments.CouponsDB_DAO;
import coupon.system.core.DAOdepartments.CustomersDB_DAO;
import coupon.system.core.db.ConnectionPool;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Category;
import coupon.system.core.javaBeans.Company;
import coupon.system.core.javaBeans.Coupon;
import coupon.system.core.javaBeans.Customer;

import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDate;

/**
 * this class was built to mainly test various methods on the sql tables.
 * we have here constant Data to use, coupons, companies, customers, coupons and coupons purchases.
 * this class also can be used to initialize the SQL tables.
 * @author nizan5866
 */
public class RestartSQL {

    private static final CompaniesDB_DAO companiesDB_dao = new CompaniesDB_DAO();
    private static final CouponsDB_DAO couponsDB_dao = new CouponsDB_DAO();
    private static final CustomersDB_DAO customersDBDao = new CustomersDB_DAO();


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    public static final Company COMPANY1 = new Company(1, "Apple", "apple@gmail.com", "1234");
    public static final Company COMPANY2 = new Company(2, "Google", "google@gmail.com", "1234");
    public static final Company COMPANY3 = new Company(3, "Amazon", "amazon@gmail.com", "1234");
    public static final Company COMPANY4 = new Company(4, "Microsoft", "microsoft@gmail.com", "1234");
    public static final Company COMPANY5 = new Company(5, "Nestle", "nestle@gmail.com", "1234");
    public static final Company COMPANY6 = new Company(6, "BeyondMeat", "beyondmeat@gmail.com", "1234");
    public static final Company COMPANY7 = new Company(7, "Booking", "booking@gmail.com", "1234");
    public static final Company COMPANY8 = new Company(8, "Walmart", "walmart@gmail.com", "1234");
    public static final Company COMPANY9 = new Company(9, "LG", "lg@gmail.com", "1234");
    public static final Company COMPANY10 = new Company(10, "Sony", "sony@gmail.com", "1234");

    public static final Company[] companies = {COMPANY1, COMPANY2, COMPANY3, COMPANY4, COMPANY5, COMPANY6, COMPANY7, COMPANY8, COMPANY9, COMPANY10};
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    public static final Coupon COUPON1 = new Coupon(1, 1, Category.ELECTRICITY, "20% off smartphones", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 100, "@@@");
    public static final Coupon COUPON2 = new Coupon(2, 1, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 200, "@@@");
    public static final Coupon COUPON3 = new Coupon(3, 1, Category.ELECTRICITY, "20% off TV's", "get 20% discount on televisions", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 300, "@@@");

    public static final Coupon COUPON4 = new Coupon(4, 2, Category.ELECTRICITY, "20% off smartphones", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 100, "@@@");
    public static final Coupon COUPON5 = new Coupon(5, 2, Category.FOOD, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 200, "@@@");
    public static final Coupon COUPON6 = new Coupon(6, 2, Category.ELECTRICITY, "20% off TV's", "get 20% discount on televisions", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 300, "@@@");

    public static final Coupon COUPON7 = new Coupon(7, 3, Category.ELECTRICITY, "20% off cloud space", "get 20% discount on cloud space", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 50, "@@@");
    public static final Coupon COUPON8 = new Coupon(8, 3, Category.ELECTRICITY, "amazon prime", "one month of amazing prime", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 30, "@@@");
    public static final Coupon COUPON9 = new Coupon(9, 3, Category.ELECTRICITY, "50$ gift card", "get 50$ gift card for amazon", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 45, "@@@");

    public static final Coupon COUPON10 = new Coupon(10, 4, Category.ELECTRICITY, "20% off office", "get 20% discount on office", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 149.9, "@@@");
    public static final Coupon COUPON11 = new Coupon(11, 4, Category.ELECTRICITY, "ONLY EXCEL", "get excel desktop program", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 49.9, "@@@");
    public static final Coupon COUPON12 = new Coupon(12, 4, Category.ELECTRICITY, "20% off computers", "get 20% discount on computers", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 79.9, "@@@");
    public static final Coupon COUPON13 = new Coupon(13, 4, Category.ELECTRICITY, "windows for students", "get windows for students at a major discount", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 300.99, "@@@");

    public static final Coupon COUPON14 = new Coupon(14, 5, Category.FOOD, "ice cream", "one ice cream at relevant stores", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 20, 0.99, "@@@");
    public static final Coupon COUPON15 = new Coupon(15, 5, Category.FOOD, "chocolate", "one chocolate bar at relevant stores", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 20, 0.99, "@@@");
    public static final Coupon COUPON16 = new Coupon(16, 5, Category.FOOD, "bread", "one bread bar at relevant stores", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 20, 0.99, "@@@");

    public static final Coupon COUPON17 = new Coupon(17, 6, Category.FOOD, "one beyond meat burger", "one beyond meat burger at relevant stores", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 4.99, "@@@");
    public static final Coupon COUPON18 = new Coupon(18, 6, Category.FOOD, "two beyond meat burger", "two beyond meat burger at relevant stores", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 8.99, "@@@");

    public static final Coupon COUPON19 = new Coupon(19, 7, Category.VACATION, "18% off hotels", "get 18% discount on hotels", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 450, "@@@");
    public static final Coupon COUPON20 = new Coupon(20, 7, Category.VACATION, "vacation in Dan Eilat", "get full vacation at dan eilat", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 3, 2499.99, "@@@");
    public static final Coupon COUPON21 = new Coupon(21, 7, Category.VACATION, "30$ for Booking hotels", "get 30$ for booking hotels not for the weekends", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 5, 29.9, "@@@");

    public static final Coupon COUPON22 = new Coupon(22, 8, Category.FOOD, "10$ for walmart", "get 10$ for purchasing food at walmart", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 7, 8.99, "@@@");
    public static final Coupon COUPON23 = new Coupon(23, 8, Category.FOOD, "breakfest at walmart", "full breakfast at walmart", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 7, 7.97, "@@@");

    public static final Coupon COUPON24 = new Coupon(24, 9, Category.ELECTRICITY, "20% off smartphones", "get 20% discount on smartphones", LocalDate.parse("2021-01-01"), LocalDate.parse("2022-12-31"), 2, 74.76, "@@@");

    public static final Coupon[] coupons = {COUPON1, COUPON2, COUPON3, COUPON4, COUPON5, COUPON6, COUPON6, COUPON7, COUPON8, COUPON9,
            COUPON10, COUPON11, COUPON12, COUPON13, COUPON14, COUPON15, COUPON16, COUPON17, COUPON18,
            COUPON19, COUPON20, COUPON21, COUPON22, COUPON23, COUPON24};
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    public static final Customer CUSTOMER1 = new Customer(1, "Avraham", "Cohen", "avrahamcohen@gmail.com", "1234");
    public static final Customer CUSTOMER2 = new Customer(2, "Beny", "Gabbay", "benygabbay@gmail.com", "1234");
    public static final Customer CUSTOMER3 = new Customer(3, "Dana", "Cohen", "danacohen@gmail.com", "1234");
    public static final Customer CUSTOMER4 = new Customer(4, "Fiona", "Floochi", "fionafloochi@gmail.com", "1234");
    public static final Customer CUSTOMER5 = new Customer(5, "Gabi", "Gavrielov", "gabigavrielov@gmail.com", "1234");
    public static final Customer CUSTOMER6 = new Customer(6, "Kobi", "Cohen", "kobicohen@gmail.com", "1234");
    public static final Customer CUSTOMER7 = new Customer(7, "Mona", "Levi", "monalevi@gmail.com", "1234");
    public static final Customer CUSTOMER8 = new Customer(8, "Ronen", "Levi", "ronenlevi@gmail.com", "1234");
    public static final Customer CUSTOMER9 = new Customer(9, "Sarah", "abutbul", "sarahabutbul@gmail.com", "1234");
    public static final Customer CUSTOMER10 = new Customer(10, "Tzlil", "Gabbay", "tzlilgabbay@gmail.com", "1234");

    public static final Customer[] customers = {CUSTOMER1, CUSTOMER2, CUSTOMER3, CUSTOMER4, CUSTOMER5, CUSTOMER6, CUSTOMER7,
            CUSTOMER8, CUSTOMER9, CUSTOMER10};
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * this function drops all the tables in the coupons_sys_db and restores them.
     * this method is also used to initialize the tables if they are not yet made.
     * so, it's also malfunctions as my SQL script for creating the tables
     */
    public static void emptyAllTables() throws CouponSystemException {
        Connection con = ConnectionPool.getInstance().getConnection();
        try {
            String sql1 = "drop table customers_vs_coupons;";
            String sql2 = "drop table customers;";
            String sql3 = "drop table coupons;";
            String sql4 = "drop table companies;";
            String sql5 = "drop table categories;";
            String sql6 = """
                    create table `companies`(
                    `id` int primary key auto_increment,
                    `name` varchar(30) not null,
                    `Email` varchar(30) unique not null,
                    `password` varchar(30) not null
                    );""";
            String sql7 = """
                    create table `customers`(
                    `id` int primary key auto_increment,
                    `first_name` varchar(30) not null,
                    `last_name` varchar(30) not null,
                    `Email` varchar(30) unique not null,
                    `password` varchar(30) not null
                    );""";
            String sql8 = """
                    create table `categories`(
                    `id` int primary key,
                    `name` varchar(30) not null
                    );""";
            String sql9 = """
                    create table `coupons`(
                    `id` int primary key auto_increment,
                    `company_id` int,
                    `category_id` int,
                    `title` varchar(30) not null,
                    `description` varchar(200) not null,
                    `start_date` date not null,
                    `end_date` date not null,
                    `amount` int not null,
                    `price` double not null,
                    `image` varchar(256),
                    foreign key(`company_id`) references companies(`id`),
                    foreign key(`category_id`) references categories(`id`)
                    );""";
            String sql10 = """
                    create table `customers_vs_coupons`(
                    `customer_id` int,
                    `coupon_id` int,
                    primary key(customer_id, coupon_id),
                    foreign key(`customer_id`) references customers(`id`),
                    foreign key(`coupon_id`) references coupons(`id`)
                    );""";
            String[] sqlStatements = {sql1, sql2, sql3, sql4, sql5, sql6, sql7, sql8, sql9, sql10};
            try (Statement stmt = con.createStatement()) {
                for (String sqlStatement : sqlStatements) {
                    try {
                        stmt.executeUpdate(sqlStatement);
                    } catch (Exception e) {
                    }
                }
                System.out.println("tables dropped and restored");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ConnectionPool.getInstance().restoreConnection(con);
        }

    }

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


    /**
     * this function initializing the coupons_sys_db with some initial data to work with
     */
    public static void restartSQL() {
        try {
            emptyAllTables();
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
        String sql1 = "insert into categories values(0, \"Food\");";
        String sql2 = "insert into categories values(1, \"Electricity\")";
        String sql3 = "insert into categories values(2, \"Restaurant\");";
        String sql4 = "insert into categories values(3, \"Vacation\");";
        String[] sqlStatements = {sql1, sql2, sql3, sql4};
        Connection con = null;
        try {
            con = ConnectionPool.getInstance().getConnection();
            try (Statement stmt = con.createStatement()) {
                for (String sqlStatement : sqlStatements) {
                    stmt.executeUpdate(sqlStatement);
                }
                for (Company company : companies) {
                    companiesDB_dao.addCompany(company);
                }
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println("<><>     # finished adding all companies #        <><>");
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println();
                for (Customer customer : customers) {
                    customersDBDao.addCustomer(customer);
                }
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println("<><>      @ finished adding all customers @       <><>");
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println();
                for (Coupon coupon : coupons) {
                    couponsDB_dao.addCoupon(coupon);
                }
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println("<><>       $ finished adding all coupons $        <><>");
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println();
                addCouponPurchases();
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println("<><>  & finished adding all coupons purchases &   <><>");
                System.out.println("<><><><><><><><><><><><><><><><><><><><><><><><><><><>");
                System.out.println("""
                                                            
                        ~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~
                        ~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~
                        ~*~*~*~*~*~*     SQL coupons_sys_db        *~*~*~*~*~*~
                        ~*~*~*~*~*~*   INITIALIZED SUCCESSFULLY    *~*~*~*~*~*~
                        ~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~
                        ~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~
                                                            
                        """);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(con != null) {
                ConnectionPool.getInstance().restoreConnection(con);
            }
        }
    }

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * this function add some data to the customers_vs_coupons table at the coupon_sys_db.
     * it's only use is for the `restartSQL() method` and that is why it is private.
     *
     * @throws CouponSystemException if something goes wrong with the database
     */
    private static void addCouponPurchases() throws CouponSystemException {
        couponsDB_dao.addCouponPurchase(1, 1);
        couponsDB_dao.addCouponPurchase(1, 2);
        couponsDB_dao.addCouponPurchase(1, 3);
        couponsDB_dao.addCouponPurchase(2, 1);
        couponsDB_dao.addCouponPurchase(2, 3);
        couponsDB_dao.addCouponPurchase(3, 20);
        couponsDB_dao.addCouponPurchase(3, 21);
        couponsDB_dao.addCouponPurchase(4, 13);
        couponsDB_dao.addCouponPurchase(5, 16);
        couponsDB_dao.addCouponPurchase(6, 17);
        couponsDB_dao.addCouponPurchase(7, 17);
        couponsDB_dao.addCouponPurchase(8, 18);
        couponsDB_dao.addCouponPurchase(9, 1);
        couponsDB_dao.addCouponPurchase(9, 2);
        couponsDB_dao.addCouponPurchase(9, 3);
        couponsDB_dao.addCouponPurchase(9, 4);
        couponsDB_dao.addCouponPurchase(9, 5);
        couponsDB_dao.addCouponPurchase(9, 6);
        couponsDB_dao.addCouponPurchase(9, 7);
        couponsDB_dao.addCouponPurchase(9, 8);
        couponsDB_dao.addCouponPurchase(9, 9);
    }

}