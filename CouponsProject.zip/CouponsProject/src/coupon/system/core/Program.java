package coupon.system.core;

import coupon.system.core.test.Test;


/**
 * @author nizan5866
 */
public class Program {
    public static void main(String[] args) {

        Test.testAll();
    }
}
