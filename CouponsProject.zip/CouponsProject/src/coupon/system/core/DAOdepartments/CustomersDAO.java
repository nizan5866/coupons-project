package coupon.system.core.DAOdepartments;

import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Customer;

import java.util.List;

public interface CustomersDAO {

    /**
     * this method is used to check if a Customer exists at the relevant DataBase
     * @param email the Customer Email
     * @param password the Customer password
     * @return true if the customer exists in the database based on the Email and Password and false if not
     * @throws CouponSystemException if there is a problem with finding the Customer in the database
     */
    public boolean isCustomerExists(String email, String password) throws CouponSystemException;

    /**
     * this method is used to check if a Customer exists at the relevant DataBase
     * @param email the Customer Email
     * @return true if the customer exists in the database based on the Email and false if not
     * @throws CouponSystemException if there is a problem with finding the Customer in the database
     */
    public boolean isCustomerExistsByEmail(String email) throws CouponSystemException;

    /**
     * this method is used to check if a Customer exists at the relevant DataBase
     * @param customerID the Customer ID
     * @return true if the customer exists in the database based on the give ID and false if not
     * @throws CouponSystemException if there is a problem with finding the Customer in the database
     */
    public boolean isCustomerExists(int customerID) throws CouponSystemException;

    /**
     * this method is for getting a specific customerID from the database using customer email
     * @param customerEmail customer email according to the database
     * @return the customer id if it does exist
     * @throws CouponSystemException if there is a problem with the database
     */
    public int getCustomerID(String customerEmail) throws CouponSystemException;

    /**
     * this method is used to add a customer to the Database
     * @param customer an Object from the class Customer
     * @throws CouponSystemException if there is a problem with adding the customer
     * to the database
     */
    public void addCustomer(Customer customer) throws CouponSystemException;

    /**
     * this method is used for updating a customer in the database relying on the given Object ID
     * @param customer an Object from the class Customer
     * @throws CouponSystemException if there is a problem with updating the customer in the data base
     */
    public void updateCustomer(Customer customer) throws CouponSystemException;

    /**
     * this method is used for deleting a Customer from the data base comparing it to given ID
     * @param customerID the ID of the customer you wish to delete from the database
     * @throws CouponSystemException if there is a problam with deleting the customer from the database
     */
    public void deleteCustomer(int customerID) throws CouponSystemException;

    /**
     * this method is used for getting all the customers from the database
     * @return a sorted ArrayList by the customers last name and then name, from the database
     * @throws CouponSystemException if there is a problem with getting the information from the
     * database
     */
    public List<Customer> getAllCustomers() throws CouponSystemException;

    /**
     * this method is for getting a specific customer from the database using the customer ID
     * @param customerID customer ID according to the database
     * @return an Object from the class Customer representing the relevant customers from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public Customer getOneCustomer(int customerID) throws CouponSystemException;

    /**
     * this method is used to delete all of the company's purchased coupons
     * @param customerID Customer ID according to the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public void deleteAllCustomerPurchasedCoupons(int customerID) throws CouponSystemException;


}
