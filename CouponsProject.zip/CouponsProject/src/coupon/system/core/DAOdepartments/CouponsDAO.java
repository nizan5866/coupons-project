package coupon.system.core.DAOdepartments;

import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Category;
import coupon.system.core.javaBeans.Coupon;

import java.time.LocalDate;
import java.util.List;

public interface CouponsDAO {

    /**
     * this method is used for adding a coupon for the database
     *
     * @param coupon this is an object from the class Coupon
     * @throws CouponSystemException if there is a problem with accessing to the database
     */
    public void addCoupon(Coupon coupon) throws CouponSystemException;

    /**
     * this method is used to check if a coupon title
     * already exists in the selected Company
     *
     * @param CouponTitle The coupon titles to be checked
     * @param CompanyID   The Company ID wished to be checked
     * @return true if Coupon with the same title already exists and false
     * if it is not
     * @throws CouponSystemException if there is a problem with accessing to the database
     */
    public boolean isCouponExistInCompanyByTitle(String CouponTitle, int CompanyID) throws CouponSystemException;


    /**
     * this method is used for updating information about a coupon using the coupon ID
     *
     * @param coupon this is an object from the class Coupon
     * @throws CouponSystemException if there is a problem with accessing to the database
     */
    public void updateCoupon(Coupon coupon) throws CouponSystemException;

    /**
     * this method is used for using an integer number referencing a coupon id,
     * for look up in the database for deleting it.
     *
     * @param couponID Coupon ID according to the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public void deleteCoupon(int couponID) throws CouponSystemException;

    /**
     * this method is used for getting all the coupons from the database
     *
     * @return a sorted ArrayList by the coupons ID from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCoupons() throws CouponSystemException;

    /**
     * this method is used for getting all the coupons from the database
     * that belong to a specific customer
     *
     * @param customerID the relevant customer ID
     * @return a sorted ArrayList by the coupons ID from the database
     * @throws CouponSystemException if there is aa problem with the database
     */
    public List<Coupon> getAllCouponsOfCustomer(int customerID) throws CouponSystemException;

    /**
     * this method returns a list of all coupons of a specific customer of a specific
     * category
     *
     * @param customerID the relevant customer ID
     * @param category   the relevant category
     * @return a sorted ArrayList by the coupons ID from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCouponsOfCustomerByCategory(int customerID, Category category)
            throws CouponSystemException;

    /**
     * this method returns a sorted list of all coupons of a specific customer which
     * price is lower the the maxPrice given
     *
     * @param customerID the relevant customer ID
     * @param maxPrice   the maximum price a coupon in the list can be
     * @return a sorted list by price of coupons
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCouponsOfCustomerByMaxPrice(int customerID, double maxPrice) throws CouponSystemException;

    /**
     * this method is used for getting all the coupons from the database
     * that belong to a specific company
     *
     * @param companyID the company id relevant
     * @return a sorted ArrayList by the coupons ID from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCouponsOfCompany(int companyID) throws CouponSystemException;


    /**
     * this method returns a list of all coupons of a specific company of a specific
     * category
     *
     * @param companyID the relevant company ID
     * @param category  the relevant category
     * @return a sorted ArrayList by the coupons ID from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCouponsOfCompanyByCategory(int companyID, Category category) throws CouponSystemException;


    /**
     * this method returns a sorted list of all coupons of a specific company which
     * price is lower the the maxPrice given
     *
     * @param companyID the relevant company ID
     * @param maxPrice  the maximum price a coupon in the list can be
     * @return a sorted list by price of coupons
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCouponsOfCompanyByMaxPrice(int companyID, double maxPrice) throws CouponSystemException;

    /**
     * this method is for getting a specific company from the database using company ID
     *
     * @param couponID Coupon ID according to the database
     * @return an Object from the class Coupon representing the relevant coupon from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public Coupon getOneCoupon(int couponID) throws CouponSystemException;

    /**
     * this method is used for adding a coupon purchase to the data base by adding the specific coupon ID
     * to a specific client ID
     *
     * @param customerID Customer ID according to the database
     * @param couponID   Coupon ID according to the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public void addCouponPurchase(int customerID, int couponID) throws CouponSystemException;

    /**
     * this method is used for reversing the method "addCouponPurchase"
     *
     * @param customerID Customer ID according to the database
     * @param couponID   Coupon ID according to the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public void deleteCouponPurchase(int customerID, int couponID) throws CouponSystemException;

    /**
     * this method is used for deleting all of the purchases of a coupon
     *
     * @param couponID the id of the coupon we want to delete
     * @throws CouponSystemException if something goes wrong with the database
     */
    public void deleteAllCouponPurchases(int couponID) throws CouponSystemException;

    /**
     * this method is used for deleting all of the coupons with end date before
     * the given date
     *
     * @param date the date by all coupons with end date before that will be deleted
     * @throws CouponSystemException if something goes wrong with the database
     */
    public void deleteAllCouponsWithEndDateBefore(LocalDate date) throws CouponSystemException;

    /**
     * this method is used for deleting all of the purchased coupons with end date before
     * the given date
     *
     * @param date the date by all coupons with end date before that will be deleted
     * @throws CouponSystemException if something goes wrong with the database
     */
    public void deleteAllCouponPurchasesWithEndDateBefore(LocalDate date) throws CouponSystemException;


    /**
     * this method is used to check if a specific customer already purchased a certain coupon
     *
     * @param couponID   the coupon Id needed to be checked
     * @param customerID the relevant customer ID
     * @return true if already purchased and false if not
     * @throws CouponSystemException if something goes wrong with the database
     */
    public boolean couponAlreadyPurchased(int couponID, int customerID) throws CouponSystemException;
}
