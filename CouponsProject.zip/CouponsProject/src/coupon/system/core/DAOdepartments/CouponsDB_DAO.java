package coupon.system.core.DAOdepartments;

import coupon.system.core.db.ConnectionPool;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Category;
import coupon.system.core.javaBeans.Coupon;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CouponsDB_DAO implements CouponsDAO {
    private final ConnectionPool connectionPool = ConnectionPool.getInstance();
    private static final String ERROR_MSG = "Unexpected error occurred";

    //=================================================================================================================

    public CouponsDB_DAO() {
    }

    //================================================================================================================

    @Override
    public void addCoupon(Coupon coupon) throws CouponSystemException {

        Connection con = connectionPool.getConnection();
        String sql2 = "insert into coupons values(0,?,?,?,?,?,?,?,?,?);";

        try (PreparedStatement pstmt = con.prepareStatement(sql2, PreparedStatement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, coupon.getCompanyID());
            pstmt.setInt(2, coupon.getCategory().ordinal());
            pstmt.setString(3, coupon.getTitle());
            pstmt.setString(4, coupon.getDescription());
            pstmt.setDate(5, Date.valueOf(coupon.getStartDate()));
            pstmt.setDate(6, Date.valueOf(coupon.getEndDate()));
            pstmt.setInt(7, coupon.getAmount());
            pstmt.setDouble(8, coupon.getPrice());
            pstmt.setString(9, coupon.getImage());
            pstmt.executeUpdate();
            try (ResultSet res = pstmt.getGeneratedKeys()) {
                res.next();
                coupon.setId(res.getInt(1));
//                System.out.println(coupon + " \nwas created.");
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

//====================================================================================================================

    @Override
    public boolean isCouponExistInCompanyByTitle(String couponTitle, int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql1 = "select id from coupons where title = ? and company_id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setString(1, couponTitle);
            pstmt.setInt(2, companyID);
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public void updateCoupon(Coupon coupon) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "Update coupons Set company_id = ?, category_id = ? , title = ?," +
                " description = ?, start_date= ?, end_date= ?, amount= ? , price = ?, image= ? where id = ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, coupon.getCompanyID());
            pstmt.setInt(2, coupon.getCategory().ordinal());
            pstmt.setString(3, coupon.getTitle());
            pstmt.setString(4, coupon.getDescription());
            pstmt.setDate(5, Date.valueOf(coupon.getStartDate()));
            pstmt.setDate(6, Date.valueOf(coupon.getEndDate()));
            pstmt.setInt(7, coupon.getAmount());
            pstmt.setDouble(8, coupon.getPrice());
            pstmt.setString(9, coupon.getImage());
            pstmt.setInt(10, coupon.getId());
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public void deleteCoupon(int couponID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "DELETE FROM coupons where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, couponID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public List<Coupon> getAllCoupons() throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons;";
        try (Statement stmt = con.createStatement();
             ResultSet res = stmt.executeQuery(sql1);) {
            while (res.next()) {
                coupons.add(getCouponRes(res));
            }
            return coupons;
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //=============================================================================================================

    @Override
    public List<Coupon> getAllCouponsOfCompany(int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons where company_id = ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, companyID);
            try (ResultSet res = pstmt.executeQuery()) {
                while (res.next()) {
                    coupons.add(getCouponRes(res));
                }
                return coupons;
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //==============================================================================================================

    @Override
    public List<Coupon> getAllCouponsOfCompanyByCategory(int companyID, Category category) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons where company_id = ? and category_id = ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, companyID);
            pstmt.setInt(2, category.ordinal());
            try (ResultSet res = pstmt.executeQuery()) {
                while (res.next()) {
                    coupons.add(getCouponRes(res));
                }
                return coupons;
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //=============================================================================================================

    @Override
    public List<Coupon> getAllCouponsOfCompanyByMaxPrice(int companyID, double maxPrice) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons where company_id = ? and price <=  ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, companyID);
            pstmt.setDouble(2, maxPrice);
            try (ResultSet res = pstmt.executeQuery()) {
                while (res.next()) {
                    coupons.add(getCouponRes(res));
                }
                return coupons;
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }


    //==============================================================================================================

    @Override
    public Coupon getOneCoupon(int couponID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select * from coupons where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, couponID);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                res.next();
                return getCouponRes(res);
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //===============================================================================================================

    /**
     * this use is only for this class to make things more readable
     * @param res
     * @return
     * @throws SQLException
     */
    private Coupon getCouponRes(ResultSet res) throws SQLException {
        int id = res.getInt("id");
        int companyID = res.getInt("company_id");
        Category category = Category.values()[res.getInt("category_id")];
        String title = res.getString("title");
        String description = res.getString("description");
        LocalDate startDate = LocalDate.parse(res.getString("start_date"));
        LocalDate endDate = LocalDate.parse(res.getString("end_date"));
        int amount = res.getInt("amount");
        double price = res.getDouble("price");
        String image = res.getString("image");
        return new Coupon(id, companyID, category, title, description, startDate, endDate, amount, price, image);
    }

    //===============================================================================================================

    @Override
    public void addCouponPurchase(int customerID, int couponID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql4 = "insert into customers_vs_coupons values(?,?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql4)) {
            pstmt.setInt(1, customerID);
            pstmt.setInt(2, couponID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //===============================================================================================================


    //idk by which elements i can delete purchase except if coupons exists (for instance
    //coupon end date relevancy?
    @Override
    public void deleteCouponPurchase(int customerID, int couponID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "Delete from customers_vs_coupons where customer_id = ? and coupon_id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, customerID);
            pstmt.setInt(2, couponID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }

    }

    //===============================================================================================================

    @Override
    public void deleteAllCouponPurchases(int couponID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "Delete from customers_vs_coupons where coupon_id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, couponID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }

    }

    //==============================================================================================================

    @Override
    public void deleteAllCouponsWithEndDateBefore(LocalDate date) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "delete from coupons where end_date < ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setDate(1, Date.valueOf(date));
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public void deleteAllCouponPurchasesWithEndDateBefore(LocalDate date) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "delete from customers_vs_coupons where coupon_id in" +
                "(select id from coupons where end_date < ?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setDate(1, Date.valueOf(date));
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }

    }

    //===============================================================================================================


    @Override
    public boolean couponAlreadyPurchased(int couponID, int customerID) throws CouponSystemException {
        String sql1 = "select* from customers_vs_coupons where customer_id = ? and coupon_id = ?;";
        Connection con = connectionPool.getConnection();
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, customerID);
            pstmt.setInt(2, couponID);
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        }finally {
            connectionPool.restoreConnection(con);
        }
    }

    //=================================================================================================================

    @Override
    public List<Coupon> getAllCouponsOfCustomer(int customerID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons where id in " +
                "(select coupon_id from customers_vs_coupons where customer_id = ?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, customerID);
            try (ResultSet res = pstmt.executeQuery()) {
                while (res.next()) {
                    coupons.add(getCouponRes(res));
                }
                return coupons;
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public List<Coupon> getAllCouponsOfCustomerByCategory(int customerID, Category category)
            throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons where category_id = ? and id in" +
                "(select coupon_id from customers_vs_coupons where customer_id = ?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, category.ordinal());
            pstmt.setInt(2, customerID);
            try (ResultSet res = pstmt.executeQuery()) {
                while (res.next()) {
                    coupons.add(getCouponRes(res));
                }
                return coupons;
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public List<Coupon> getAllCouponsOfCustomerByMaxPrice(int customerID, double maxPrice) throws CouponSystemException{
        Connection con = connectionPool.getConnection();
        List<Coupon> coupons = new ArrayList<>();
        String sql1 = "select * from coupons where price <= ? and id in" +
                "(select coupon_id from customers_vs_coupons where customer_id = ?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setDouble(1, maxPrice);
            pstmt.setInt(2, customerID);
            try (ResultSet res = pstmt.executeQuery()) {
                while (res.next()) {
                    coupons.add(getCouponRes(res));
                }
                return coupons;
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

}
