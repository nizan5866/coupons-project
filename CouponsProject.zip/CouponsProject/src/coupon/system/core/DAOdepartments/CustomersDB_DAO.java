package coupon.system.core.DAOdepartments;

import coupon.system.core.db.ConnectionPool;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomersDB_DAO implements CustomersDAO {

    private final ConnectionPool connectionPool = ConnectionPool.getInstance();
    private static final String ERROR_MSG = "Unexpected error occurred";

    //================================================================================================================

    public CustomersDB_DAO() {
    }

    //================================================================================================================

    @Override
    public boolean isCustomerExists(String email, String password) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select Email, password from customers where Email = ? and password = ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2);) {
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    public boolean isCustomerExistsByEmail(String email) throws CouponSystemException{
        Connection con = connectionPool.getConnection();
        String sql2 = "select Email from customers where Email = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2);) {
            pstmt.setString(1, email);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }
    //===============================================================================================================

    @Override
    public void addCustomer(Customer customer) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "insert into customers values(0,?,?,?,?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql2, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPassword());
            pstmt.executeUpdate();
            try (ResultSet res = pstmt.getGeneratedKeys()) {
                res.next();
                customer.setId(res.getInt(1));
//                System.out.println(customer + " \nwas created.");
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //==============================================================================================================

    @Override
    public void updateCustomer(Customer customer) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "Update customers Set first_name = ? , last_name = ? , Email = ? ," +
                " password = ? where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPassword());
            pstmt.setInt(5, customer.getId());
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }

    }

    //==============================================================================================================

    @Override
    public void deleteCustomer(int customerID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "DELETE FROM customers where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, customerID);
            pstmt.executeUpdate();
//            System.out.println("Customer with id " + customerID + "was deleted from DB."); // delete?
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //==============================================================================================================

    @Override
    public List<Customer> getAllCustomers() throws CouponSystemException {
        List<Customer> companyList = new ArrayList<>();
        Connection con = connectionPool.getConnection();
        String sql1 = "select * from customers;";
        try (Statement stmt = con.createStatement(); ResultSet res = stmt.executeQuery(sql1)) {
            while (res.next()) {
                companyList.add(getCustomerRes(res));
            }
            companyList.sort(null);
            return companyList; // missing coupons list.
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //=================================================================================================================

    @Override
    public Customer getOneCustomer(int customerID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select * from customers where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, customerID);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                res.next();
                return getCustomerRes(res); // missing coupon list.
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }

    }
    //===============================================================================================================

    // this method is only for the usage of the methods "getOneCustomer" and "getAllCustomers"
    private Customer getCustomerRes(ResultSet res) throws SQLException {
        int cID = res.getInt(1); // company id from db
        String cName = res.getString(2); // company name from db
        String cLastName = res.getString(3); // company name from db
        String cEmail = res.getString(4); //company Email from db
        return new Customer(cID, cName, cLastName, cEmail);
    }

    //============================================================================================================

    @Override
    public boolean isCustomerExists(int customerID) throws CouponSystemException {
        String sql2 = "select id from customers where id = ? ;";
        Connection con = connectionPool.getConnection();
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, customerID);
            pstmt.executeQuery();
            try (ResultSet rs = pstmt.executeQuery();) {
                return rs.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //======================================================================================================

    @Override
    public int getCustomerID(String customerEmail) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select id from customers where Email = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setString(1, customerEmail);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                res.next();
                return res.getInt(1);
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }
    //===============================================================================================================

    @Override
    public void deleteAllCustomerPurchasedCoupons(int customerID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql1 = "delete from customers_vs_coupons where customer_id = ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, customerID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }


}
