package coupon.system.core.DAOdepartments;

import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Company;

import java.sql.SQLException;
import java.util.List;

public interface CompaniesDAO {

    /**
     * this method is used to check if a company exists at the relevant DataBase
     * @param email Company Email
     * @param password Company Password
     * @return boolean true if the company exists and false if it is not
     * @throws CouponSystemException if there is some problem with the Database
     */
    public boolean isCompanyExists(String email, String password) throws CouponSystemException;

    /**
     * this method is used to check if a company exists at the relevant DataBase
     * @param email Company Email
     * @return boolean true if the company exists and false if it is not
     * @throws CouponSystemException if there is some problem with the Database
     */
    public boolean isCompanyExistsByEmail(String email) throws CouponSystemException;

    /**
     * this method is used to check if a company exists at the relevant DataBase
     * @param companyName Company name
     * @return boolean true if the company exists and false if it is not
     * @throws CouponSystemException if there is some problem with the Database
     */
    public boolean isCompanyExistsByName(String companyName) throws CouponSystemException;

    /**
     * this method is used to check if a company exists at the database according to company ID
     * @param companyID Company id
     * @return true if its exist and false if it is not
     * @throws CouponSystemException if there is some problem with the Database
     */
    public boolean isCompanyExists(int companyID) throws CouponSystemException;

    /**
     * this method is used for adding a company to the relevant DataBase
     * @param company an object from the Class Company
     * @throws CouponSystemException if there is a problem with adding the
     * company to the DataBase
     */
    public void addCompany(Company company) throws CouponSystemException;

    /**
     * this method is used for updating information about a company using the company ID
     * @param company an object from the class Company
     * @throws CouponSystemException if there is a problem with updating the company
     * in the Database
     */
    public void updateCompany(Company company) throws CouponSystemException;

    /**
     *this method is used for using an integer number referencing a company id,
     * for look up in the database for deleting it.
     * @param companyID Company ID according to the database
     * @throws CouponSystemException if the company does not exist in the database
     */
    public void deleteCompany(int companyID) throws CouponSystemException;


    /**
     * this method is used for getting all the companies from the database
     * @return a sorted ArrayList by the companies name from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Company> getAllCompanies() throws CouponSystemException;


    /**
     * this method is for getting a specific company from the database using company ID
     * @param companyID Company ID according to the database
     * @return an Object from the class Company representing the relevant company from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public Company getOneCompany(int companyID) throws CouponSystemException;

    /**
     * this method is for getting a specific companyID from the database using company email
     * @param companyEmail Company email according to the database
     * @return the company ID if it is exists
     * @throws CouponSystemException if there is a problem with the database
     */
    public int getCompanyID(String companyEmail) throws CouponSystemException;

    /**
     * this method is used to delete all of the company coupons
     * @param companyID Company ID according to the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public void deleteAllCompanyCoupons(int companyID) throws CouponSystemException;

    /**
     * this method is used to delete all of the company's purchased coupons
     * @param companyID Company ID according to the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public void deleteAllCompanyPurchasedCoupons(int companyID) throws CouponSystemException;
}
