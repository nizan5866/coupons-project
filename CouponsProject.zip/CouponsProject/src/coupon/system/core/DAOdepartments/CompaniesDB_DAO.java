package coupon.system.core.DAOdepartments;

import coupon.system.core.db.ConnectionPool;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Company;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CompaniesDB_DAO implements CompaniesDAO {

    private final ConnectionPool connectionPool = ConnectionPool.getInstance();
    private static final String ERROR_MSG = "Unexpected error occurred";

    //===============================================================================================================


    @Override
    public boolean isCompanyExists(String email, String password) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select * from companies where Email = ? and password = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public boolean isCompanyExists(int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select id from companies where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, companyID);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

//====================================================================================================================

    @Override
    public boolean isCompanyExistsByEmail(String email) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select * from companies where Email = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setString(1, email);
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

//====================================================================================================================

    @Override
    public boolean isCompanyExistsByName(String companyName) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select * from companies where name = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setString(1,companyName );
            pstmt.executeQuery();
            try (ResultSet res = pstmt.executeQuery()) {
                return res.next();
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //===============================================================================================================

    //pay attention. when u print company that already exists in data base. it will say it's id is 0.
    @Override
    public void addCompany(Company company) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "insert into companies values(0,?,?,?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql2, PreparedStatement.RETURN_GENERATED_KEYS);) {
            pstmt.setString(1, company.getName());
            pstmt.setString(2, company.getEmail());
            pstmt.setString(3, company.getPassword());
            pstmt.executeUpdate();
            try (ResultSet res = pstmt.getGeneratedKeys();) {
                res.next();
                company.setId(res.getInt(1));
//                System.out.println(company + " \nwas created.");
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public void updateCompany(Company company) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "Update companies Set name = ? , Email = ? , password = ? where id = ?;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setString(1, company.getName());
            pstmt.setString(2, company.getEmail());
            pstmt.setString(3, company.getPassword());
            pstmt.setInt(4, company.getId());
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================


    @Override
    public void deleteCompany(int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "DELETE FROM companies where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2)) {
            pstmt.setInt(1, companyID);
            pstmt.executeUpdate();
//            System.out.println("Company with id " + companyID + " was deleted from DB.");
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //===============================================================================================================

    @Override
    public void deleteAllCompanyPurchasedCoupons(int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql1 = "delete from customers_vs_coupons where coupon_id in " +
                "(select id from coupons where company_id = ?);";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, companyID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================


    @Override
    public void deleteAllCompanyCoupons(int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql1 = "delete from coupons where company_id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql1)) {
            pstmt.setInt(1, companyID);
            pstmt.executeUpdate();
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }

    }




    //================================================================================================================

    @Override
    public List<Company> getAllCompanies() throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        List<Company> companyList = new ArrayList<>();
        String sql1 = "select * from companies;";
        try (Statement stmt = con.createStatement(); ResultSet res = stmt.executeQuery(sql1)) {
            while (res.next()) {
                companyList.add(getCompanyRes(res));
            }
            companyList.sort(null);
            return companyList; // missing coupons list.
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        } finally {
            connectionPool.restoreConnection(con);
        }
    }

    //================================================================================================================

    @Override
    public Company getOneCompany(int companyID) throws CouponSystemException {
        Connection con = connectionPool.getConnection();
        String sql2 = "select * from companies where id = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2);) {
            pstmt.setInt(1, companyID);
            try (ResultSet res = pstmt.executeQuery()) {
                res.next();
                return getCompanyRes(res); // missing coupon list.
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        }finally {
            connectionPool.restoreConnection(con);
        }
    }

    //===============================================================================================================

    @Override
    public int getCompanyID(String companyEmail) throws CouponSystemException{
        Connection con = connectionPool.getConnection();
        String sql2 = "select id from companies where Email = ? ;";
        try (PreparedStatement pstmt = con.prepareStatement(sql2);) {
            pstmt.setString(1, companyEmail);
            try (ResultSet res = pstmt.executeQuery()) {
                res.next();
                return res.getInt(1);
            }
        } catch (Exception e) {
            throw new CouponSystemException(ERROR_MSG, e);
        }finally{
            connectionPool.restoreConnection(con);
        }
    }

    //===============================================================================================================

    // this method is only for the usage of the methods "getOneCompany" and "getAllCompanies"
    private Company getCompanyRes(ResultSet res) throws SQLException {
        int cID = res.getInt(1); // company id from db
        String cName = res.getString(2); // company name from db
        String cEmail = res.getString(3); //company Email from db
        // i guess im missing company coupons?
        return new Company(cID, cName, cEmail);
    }
}
