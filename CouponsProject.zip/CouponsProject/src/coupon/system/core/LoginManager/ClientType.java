package coupon.system.core.LoginManager;

public enum ClientType {

    ADMINISTRATOR,
    COMPANY,
    CUSTOMER;
}
