package coupon.system.core.LoginManager;


import coupon.system.core.FACADEdepartments.AdminFacade;
import coupon.system.core.FACADEdepartments.ClientFacade;
import coupon.system.core.FACADEdepartments.CompanyFacade;
import coupon.system.core.FACADEdepartments.CustomerFacade;
import coupon.system.core.db.ConnectionPool;
import coupon.system.core.exception.CouponSystemException;

public class LoginManager {
    private final AdminFacade adminFacade = new AdminFacade();


    private LoginManager() {
    }



    //==============================================================================================================

    /**
     * this class is for the Bill Pugh method of singleton
     */
    private static class SingletonHelper {
        public static final LoginManager INSTANCE = new LoginManager();
    }

//==================================================================================================================

    /**
     * @return getInstance
     */
    public static LoginManager getInstance() {
        return LoginManager.SingletonHelper.INSTANCE;
    }

//==================================================================================================================

    public ClientFacade login(String email, String password, ClientType clientType) throws CouponSystemException {
        ClientFacade clientFacade;
        switch (clientType) {
            case ADMINISTRATOR -> {
                clientFacade = adminFacade;
                if (clientFacade.login(email, password)) {
                    return clientFacade;
                } else {
                    return null;
                }
            }
            case COMPANY -> {
                clientFacade = new CompanyFacade();
                if (clientFacade.login(email, password)) {
                    return clientFacade;
                } else {
                    return null;
                }
            }
            default -> {
                clientFacade = new CustomerFacade();
                if (clientFacade.login(email, password)) {
                    return clientFacade;
                } else {
                    return null;
                }

            }
        }
    }
}
