package coupon.system.core.db;

import coupon.system.core.exception.CouponSystemException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ConnectionPool {

    private final Set<Connection> connections = new HashSet<>();
    private final String URL = "jdbc:mysql://localhost:3306/coupon_sys_db?createDatabaseIfNotExist=true";
    private final String USER = "root";
    private final String PASS = "1234";
    public static final int MAX_SIZE = 10;
    private boolean poolOpen;

//===================================================================================================================

    /**
     * CTOR - initializing the connection set, filling it with new connections for mySQL
     *
     * @throws SQLException if something goes wrong with the DriverManager.getConnection method
     */
    private ConnectionPool() throws SQLException {
        poolOpen = true;
        for (int i = 0; i < MAX_SIZE; i++) {
            this.connections.add(DriverManager.getConnection(URL, USER, PASS));
        }
        System.out.println("Connection pool initialized with <<< " + connections.size() + " >>> connections");
    }
//===================================================================================================================

    /**
     * this class is for the Bill Pugh method of singleton
     */
    private static class SingletonHelper {
        private static final ConnectionPool INSTANCE;

        static {
            ConnectionPool INSTANCE1;
            try {
                INSTANCE1 = new ConnectionPool();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                INSTANCE1 = null;
            }
            INSTANCE = INSTANCE1;
        }
    }

//==================================================================================================================

    /**
     * @return ConnectionPool object that represents the singleton
     */
    public static ConnectionPool getInstance() {
        return SingletonHelper.INSTANCE;
    }

//==================================================================================================================


    /**
     * This method is for getting a connection for the connection pool. if the pool is open but empty,
     * the thread requesting the connection will wait until a connection is restored.
     *
     * @return Connection returns connection from the connection pool to use for my SQL
     * @throws CouponSystemException if the pool is closed
     */
    public synchronized Connection getConnection() throws CouponSystemException {
        if (!poolOpen) {
            throw new CouponSystemException("getConnection failed - pool is closed");
        }
        while (this.connections.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Iterator<Connection> it = this.connections.iterator();
        Connection con = it.next();
        it.remove();
        return con;
    }

//===================================================================================================================

    /**
     * this method is used for restoring a connection to the connection pool.
     * this is a synchronized method so only one thread can access it at one time.
     *
     * @param con connection that specifically achieved from THIS connection pool class
     */
    public synchronized void restoreConnection(Connection con) {
        this.connections.add(con);
        notify();
    }




    //===============================================================================================================

    /**
     * this method is used to close all the connections in the connection pool after all the
     * connections has been restored.
     * @throws CouponSystemException if for SQL reason the connection close has failed
     */
    public synchronized void closeAllConnections() throws CouponSystemException {
        poolOpen = false;
        while (this.connections.size() < MAX_SIZE) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        try {
            for (Connection connection : connections) {
                connection.close();
            }
            System.out.println("Connection pool closed <<< " + connections.size() + " >>> connections");
        } catch (SQLException e) {
            throw new CouponSystemException("closeAllConnections failed", e);
        }
    }
}
