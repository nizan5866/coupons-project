package coupon.system.core.FACADEdepartments;

import coupon.system.core.DAOdepartments.CompaniesDB_DAO;
import coupon.system.core.DAOdepartments.CustomersDB_DAO;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Company;
import coupon.system.core.javaBeans.Customer;

import java.util.List;

/**
 * @author nizan5866
 */
public class AdminFacade extends ClientFacade {

    /**
     * CTOR
     */
    public AdminFacade() {
        this.companiesDAO = new CompaniesDB_DAO();
        this.customersDAO = new CustomersDB_DAO();
    }

    @Override
    public boolean login(String email, String password) {
        return email.equals("admin@admin.com") && (password.equals("admin"));
    }

    /**
     * this method is used to add a new company to the data base.
     * if the company name AND email is uniq, and there isn't any null
     * argument, the company will be added to the SQL database.
     *
     * @param company an object from the class Company
     * @throws CouponSystemException if something of the mentioned above has occurred
     */
    public void addNewCompany(Company company) throws CouponSystemException {
        try {
            boolean checkerEmail = companiesDAO.isCompanyExistsByEmail(company.getEmail());
            boolean checkerName = companiesDAO.isCompanyExistsByName(company.getName());
            if (!checkerEmail && !checkerName) {
                companiesDAO.addCompany(company);
            } else if (checkerEmail && checkerName) {
                throw new CouponSystemException("company/ies with same Email AND the same name already exists");
            } else if (checkerName) {
                throw new CouponSystemException("company with the same name already exists");
            } else {
                throw new CouponSystemException("company with the same Email already exists");
            }
        } catch (CouponSystemException e) {
            throw new CouponSystemException("cannot add that company because: ", e);
        }
    }

    /**
     * this method is used to update an existing company (that doesnt exists in the database)
     *
     * @param company an object from the class Company
     * @throws CouponSystemException throws if the company name has changed, or there is a problem with accessing
     *                               the database
     */
    public void updateCompany(Company company) throws CouponSystemException {
        try {
            Company company1 = getOneCompany(company.getId());
            if (company1.getName().equals(company.getName())) {
                    companiesDAO.updateCompany(company);
            } else {
                throw new CouponSystemException("Cannot change company's name");
            }
        } catch (CouponSystemException e) {
            throw new CouponSystemException("updating Company failed: ", e);
        }
    }

    /**
     * this method is used to the delete a company from the SQL database safely.
     * it's also removes all the companies coupons and the company coupons that
     * been purchase by clients.
     *
     * @param companyID Company ID according to the database
     * @throws CouponSystemException if there is a problem with deleting the company
     *                               from the database
     */
    public void deleteCompany(int companyID) throws CouponSystemException {
        try {
            if (!companiesDAO.isCompanyExists(companyID)) {
                throw new CouponSystemException("company with ID [" + companyID + "] does not exist.");
            }
            companiesDAO.deleteAllCompanyPurchasedCoupons(companyID);
            companiesDAO.deleteAllCompanyCoupons(companyID);
            companiesDAO.deleteCompany(companyID);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("delete company failed", e);
        }
    }

    /**
     * this method is used for getting all the companies from the database
     *
     * @return a sorted ArrayList by the companies name from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Company> getAllCompanies() throws CouponSystemException {
        try {
            List<Company> companies = companiesDAO.getAllCompanies();
            if (companies.size() == 0) {
                throw new CouponSystemException("there's no any company");
            }
            return companies;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("get all companies failed", e);
        }
    }

    /**
     * this method is for getting a specific company from the database using company ID
     *
     * @param companyID Company ID according to the database
     * @return an Object from the class Company representing the relevant company from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public Company getOneCompany(int companyID) throws CouponSystemException {
        try {
            return companiesDAO.getOneCompany(companyID);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("cannot find company with id[" + companyID + "]");
        }
    }

    /**
     * this method is used to add a customer to the Database
     *
     * @param customer an Object from the class Customer
     * @throws CouponSystemException if there is a problem with adding the customer
     *                               to the database
     */
    public void addNewCustomer(Customer customer) throws CouponSystemException {
        try {
            customersDAO.addCustomer(customer);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("customer with that same Email already exists." +
                    " cannot create another customer with the same Email.");
        }
    }

    /**
     * this method is used for updating a customer in the database relying on the given Object ID
     *
     * @param customer an Object from the class Customer
     * @throws CouponSystemException if the client isn't in the data base or there is a problem with the database
     */
    public void updateCustomer(Customer customer) throws CouponSystemException {
        if (!customersDAO.isCustomerExists(customer.getId())) {
            throw new CouponSystemException("cannot find customer with id[" + customer.getId() + "]");
        }
        try {
                customersDAO.updateCustomer(customer);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("updating customer has failed:", e);
        }
    }


    /**
     * this method is used by the administrator to delete a client from the data base
     *
     * @param customerID the customer ID as represented in the database
     * @throws CouponSystemException if the customer is not inside the database or something occurs
     *                               with the data base
     */
    public void deleteCustomer(int customerID) throws CouponSystemException {
        if (!customersDAO.isCustomerExists(customerID)) {
            throw new CouponSystemException("Customer with ID[" + customerID + "] does not exist in the database");
        }
        try {
            customersDAO.deleteAllCustomerPurchasedCoupons(customerID);
            customersDAO.deleteCustomer(customerID);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("deleting customer has failed", e);

        }
    }


    /**
     * this method is being used to achieve all of the customers inside the database by the administrator
     *
     * @return a sorted list by last name and then name of all the clients in the database
     * @throws CouponSystemException if the list is empty or there is a problem with the data base
     */
    public List<Customer> getAllCustomer() throws CouponSystemException {
        try {
            List<Customer> customers = customersDAO.getAllCustomers();
            if (customers.size() == 0) {
                throw new CouponSystemException("there's no any customer");
            }
            return customers;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getting customers has failed", e);
        }
    }

    /**
     * this method is being used to achieve a single customer from the data base based on the
     * customers ID
     *
     * @param customerID the customer ID as represented in the database
     * @return an Object from the class Customer
     * @throws CouponSystemException if there isn't a client with that ID in the database,
     *                               or something has gone wrong in the data base
     */
    public Customer getOneCustomer(int customerID) throws CouponSystemException {
        try {
            return customersDAO.getOneCustomer(customerID);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("cannot find customer with id[" + customerID + "]", e);
        }
    }

}

