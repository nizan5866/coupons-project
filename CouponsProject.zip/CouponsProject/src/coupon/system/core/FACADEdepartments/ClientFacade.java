package coupon.system.core.FACADEdepartments;

import coupon.system.core.DAOdepartments.CompaniesDAO;
import coupon.system.core.DAOdepartments.CouponsDAO;
import coupon.system.core.DAOdepartments.CustomersDAO;
import coupon.system.core.DAOdepartments.CustomersDB_DAO;
import coupon.system.core.exception.CouponSystemException;

public abstract class ClientFacade {
    protected CompaniesDAO companiesDAO;
    protected CustomersDAO customersDAO;
    protected CouponsDAO couponsDAO;

    /**
     * this method is used to access to the relevant information from the database
     * depending on the Client type
     * @param email Client Email
     * @param password Client password
     * @return true if access is granted and false if access denied
     */
    public abstract boolean login(String email, String password) throws CouponSystemException;
}
