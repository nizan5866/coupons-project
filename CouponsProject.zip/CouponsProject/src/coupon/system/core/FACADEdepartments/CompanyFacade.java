package coupon.system.core.FACADEdepartments;

import coupon.system.core.DAOdepartments.CompaniesDB_DAO;
import coupon.system.core.DAOdepartments.CouponsDB_DAO;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.Category;
import coupon.system.core.javaBeans.Company;
import coupon.system.core.javaBeans.Coupon;
import coupon.system.core.javaBeans.CouponPriceComparator;

import java.time.LocalDate;
import java.util.List;

public class CompanyFacade extends ClientFacade {
    private int companyID;


    {
        this.companiesDAO = new CompaniesDB_DAO();
        this.couponsDAO = new CouponsDB_DAO();
    }


    @Override
    public boolean login(String email, String password) throws CouponSystemException { //i added to the facade throw signature. dunno if that's the right thing to do
        boolean isCompanyExist = companiesDAO.isCompanyExists(email, password);
        if(isCompanyExist){
            this.companyID = companiesDAO.getCompanyID(email);
        }
        return isCompanyExist;
    }


    /**
     * this method is used for adding a new Coupon for the Company
     *
     * @param coupon an Object from the class Coupon
     * @throws CouponSystemException <p>
     *                               1) if the coupon company_ID field is different then this company ID <p>
     *                               2) id the end date of the coupon is before now <p>
     *                               3) something went wrong with the database <p>
     */
    public void addCoupon(Coupon coupon) throws CouponSystemException {
        try {
            //im adding this now but im sure i will delete it late because it will by automatic
            if (coupon.getCompanyID() != companyID) {
                throw new CouponSystemException("Coupon \" Company_id \" must be same to this company ID");
            }
            // will be deleted?
            if (coupon.getStartDate().isAfter(coupon.getEndDate())) {
                throw new CouponSystemException("cannot have coupon with start date after end date");
            }
            //i guess this will be deleted also
            if (coupon.getEndDate().isBefore(LocalDate.now())) {
                throw new CouponSystemException("Cannot add Coupon with end Date that is before Today");
            }
            if (!couponsDAO.isCouponExistInCompanyByTitle(coupon.getTitle(), companyID)) {
                couponsDAO.addCoupon(coupon);
            } else {
                throw new CouponSystemException("Coupon with same Title already exists in this company");
            }
        } catch (CouponSystemException e) {
            throw new CouponSystemException("cannot add that Coupon because: ", e);
        }
    }


    /**
     * this method is used to update an existing company coupon
     *
     * @param coupon the coupon with the id needed to change with updated information
     * @throws CouponSystemException <p>1) if the updated coupon came with different company id (guess will be deleted later)</p>
     *                               <p>2) if the coupon doesnt exist/belong to this company</p>
     *                               <p>3) if coupon with the same title already belong to this company</p>
     *                               <p>4) if the end date of the coupon is before the start date of the coupon</p>
     *                               <p>5) if something went wrong with the database</p>
     */
    public void updateCoupon(Coupon coupon) throws CouponSystemException {
        try {
            //guess it will be deleted later
            if (coupon.getCompanyID() != companyID) {
                throw new CouponSystemException("cannot update coupon with company_id different then this company id");
            }
            if (!isCouponExistInCompany(coupon.getId())) {
                throw new CouponSystemException("there isn't coupon with id " +
                        "[" + coupon.getId() + "] that belongs to this company[" + companyID + "]");
            }
            if (!coupon.getTitle().equals(couponsDAO.getOneCoupon(coupon.getId()).getTitle()) &&
                    (couponsDAO.isCouponExistInCompanyByTitle(coupon.getTitle(), companyID))) {
                throw new CouponSystemException("other Coupon with same Title already exists in this company");
            }
            //will be deleted?
            // anyway i decided that for now, at least it will be ok to change end date to before now.
            if (coupon.getStartDate().isAfter(coupon.getEndDate())) {
                throw new CouponSystemException("cannot have coupon with start date after end date");
            }
            couponsDAO.updateCoupon(coupon);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("update Coupon failed :", e);
        }
    }

    /**
     * \
     * this method is for checking if coupon with given id belongs to this company
     *
     * @param couponID the coupon id needed to be checked
     * @return true if it is and false if it is not
     */
    public boolean isCouponExistInCompany(int couponID) {
        try {
            Coupon coupon = couponsDAO.getOneCoupon(couponID);
            return coupon.getCompanyID() == companyID;
        } catch (CouponSystemException e) {
            return false;
        }
    }


    /**
     * this method is used for deleting a companies coupon. it is also deletes it from
     * the purchases
     *
     * @param couponID the relevant Coupon id needed to be deleted
     * @throws CouponSystemException <p>1) if there isn't a coupon with that id that belongs to this company</p>
     *                               <p>2)if something went wrong with the database</p>
     */
    public void deleteCoupon(int couponID) throws CouponSystemException {
        try {
            if (!isCouponExistInCompany(couponID)) {
                throw new CouponSystemException("there isn't coupon with id " +
                        "[" + couponID + "] that belongs to this company[" + companyID + "]");
            }
            couponsDAO.deleteAllCouponPurchases(couponID);
            couponsDAO.deleteCoupon(couponID);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("delete coupon with id [" + couponID + "] has failed: ", e);
        }
    }

    /**
     * this method is used for getting all the company coupons from the database
     *
     * @return a sorted ArrayList by the coupons name from the database
     * @throws CouponSystemException if there is a problem with the database
     */
    public List<Coupon> getAllCoupons() throws CouponSystemException {
        try {
            List<Coupon> coupons = couponsDAO.getAllCouponsOfCompany(companyID);
            if (coupons.size() == 0) {
                throw new CouponSystemException("there's no any coupon belong to this company");
            }
            return coupons;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getting all coupons failed", e);
        }
    }


    /**
     * this method use is to get all of the companies coupons from a certain category
     *
     * @param category the category of the coupons needed to extract
     * @return a sorted list of coupons by their Id
     * @throws CouponSystemException <p>1)if there isn't any coupons of that category that belongs to this company</p>
     *                               <p>2)if something goes wrong in the database</p>
     */
    public List<Coupon> getAllCouponsByCategory(Category category) throws CouponSystemException {
        try {
            List<Coupon> coupons = couponsDAO.getAllCouponsOfCompanyByCategory(companyID, category);
            if (coupons.size() == 0) {
                throw new CouponSystemException("there isn't any coupons of that category" +
                        "that belongs to this company");
            }
            return coupons;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getting all coupons failed", e);
        }
    }

    /**
     * this method is for getting all of the company coupons up to a max price
     *
     * @param maxPrice the maximum price of the coupons wanted
     * @return the list of the coupons sorted by the price
     * @throws CouponSystemException <p>1)if there isn't any coupons belong to this company under the maximum price</p>
     *                               <p>2)if something goes wrong in the database</p>
     */
    public List<Coupon> getAllCouponsByMaxPrice(double maxPrice) throws CouponSystemException {
        try {
            List<Coupon> coupons = couponsDAO.getAllCouponsOfCompanyByMaxPrice(companyID, maxPrice);
            if (coupons.size() == 0) {
                throw new CouponSystemException("there isn't any coupons lower then the price: " +
                        maxPrice + " that belongs to this company");
            }
            coupons.sort(new CouponPriceComparator());
            return coupons;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getting all coupons failed", e);
        }
    }

    /**
     * this method is used for getting all of the company details
     *
     * @return an Object of the class Company
     * @throws CouponSystemException <p>1)if something goes wrong in the database</p>
     */
    public Company getCompanyDetails() throws CouponSystemException {
        Company company = companiesDAO.getOneCompany(companyID);
        List<Coupon> coupons = couponsDAO.getAllCouponsOfCompany(companyID);
        if(coupons.size() != 0) {
            company.setCoupons(coupons);
        }
        return company;
    }
}
