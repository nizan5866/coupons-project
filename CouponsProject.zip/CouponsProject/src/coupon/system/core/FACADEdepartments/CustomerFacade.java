package coupon.system.core.FACADEdepartments;

import coupon.system.core.DAOdepartments.CompaniesDB_DAO;
import coupon.system.core.DAOdepartments.CouponsDB_DAO;
import coupon.system.core.DAOdepartments.CustomersDB_DAO;
import coupon.system.core.exception.CouponSystemException;
import coupon.system.core.javaBeans.*;

import java.time.LocalDate;
import java.util.List;

public class CustomerFacade extends ClientFacade {
    private int customerID;

    {
        this.companiesDAO = new CompaniesDB_DAO();
        this.couponsDAO = new CouponsDB_DAO();
        this.customersDAO = new CustomersDB_DAO();
    }

    @Override
    public boolean login(String email, String password) throws CouponSystemException {
        boolean isCustomerExists =  customersDAO.isCustomerExists(email, password);
        if(isCustomerExists){
            this.customerID = customersDAO.getCustomerID(email);
        }
        return isCustomerExists;
    }

    /**
     * this method is used for a safe purchasing of a coupon for a customer
     *
     * @param coupon an Object from the class Coupon
     * @throws CouponSystemException <p>1) if the coupon does not exist</p>
     *                               <p>2)if the coupon is out of stock</p>
     *                               <p>3)if the coupon is not yet available for purchase</p>
     *                               <p>4)if the coupon has passed it's expiration date</p>
     *                               <p>if the coupon was already purchased by that client</p>
     */
    public void purchaseCoupon(Coupon coupon) throws CouponSystemException {
        try {
            int couponID = coupon.getId();
            isCouponPurchasable(couponID);
            if (couponsDAO.couponAlreadyPurchased(couponID, customerID)) {
                throw new CouponSystemException("Coupon with ID [" + couponID + "] was already purchased" +
                        " by the customer with ID[" + customerID + "]");
            }
            couponsDAO.addCouponPurchase(customerID, couponID);
            coupon.setAmount(coupon.getAmount() - 1);
            couponsDAO.updateCoupon(coupon);
        } catch (CouponSystemException e) {
            throw new CouponSystemException("purchase coupon failed", e);
        }
    }


    /**
     * this method is to be used by the "isCouponPurchasable" method
     *
     * @param couponID the coupon id needed to be checked in the database
     * @return true if it exists and false if it is not
     */
    private boolean isCouponExist(int couponID) {
        try {
            couponsDAO.getOneCoupon(couponID);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * this method is used for checking of a customer can buy a coupon.
     * it's only use is in the method "purchaseCoupon" in this class.
     *
     * @param couponID the coupon id needed to be checked in the database
     * @throws CouponSystemException * <p>1) if the coupon does not exist</p>
     *                               * <p>2)if the coupon is out of stock</p>
     *                               * <p>3)if the coupon is not yet available for purchase</p>
     *                               * <p>4)if the coupon has passed it's expiration date</p>
     */
    private void isCouponPurchasable(int couponID) throws CouponSystemException {
        Coupon coupon = couponsDAO.getOneCoupon(couponID);
        if (isCouponExist(couponID)) {
            if (!LocalDate.now().isAfter(coupon.getEndDate())) {
                if (!coupon.getStartDate().isAfter(LocalDate.now())) {
                    if (!(0 < coupon.getAmount())) {
                        throw new CouponSystemException("This coupon is out of stock");
                    }
                } else {
                    throw new CouponSystemException("the coupon is not yet available for purchase");
                }
            } else {
                throw new CouponSystemException("The coupon has passed expiration date");
            }
        } else {
            throw new CouponSystemException("there isn't a coupon with that id in the database");
        }
    }

    /**
     * this method is used for getting all of the customers coupons
     *
     * @return a sorted list of coupons by their ID
     * @throws CouponSystemException <p>1) if there is no relevant coupons purchased by the client</p>
     *                               <p>2)if something went wrong with accessing the database</p>
     */
    public List<Coupon> getAllCoupons() throws CouponSystemException {
        try {
            List<Coupon> coupons = couponsDAO.getAllCouponsOfCustomer(customerID);
            if (coupons.size() == 0) {
                throw new CouponSystemException("there isn't any coupons purchased by client id[" + customerID + "]");
            }
            return coupons;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getAllCoupons failed:", e);
        }
    }

    /**
     * this method use is to get all of the customer coupons from a certain category
     *
     * @param category the category of the coupons needed to extract
     * @return a sorted list of coupons by their Id
     * @throws CouponSystemException <p>1)if there isn't any coupons of that category that belongs to this customer</p>
     *                               <p>2)if something goes wrong in the database</p>
     */
    public List<Coupon> getAllCouponsByCategory(Category category) throws CouponSystemException {
        try {
            List<Coupon> coupons = couponsDAO.getAllCouponsOfCustomerByCategory(customerID, category);
            if (coupons.size() == 0) {
                throw new CouponSystemException("there isn't any coupons of that category" +
                        " that belongs to this customer");
            }
            return coupons;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getting all coupons failed", e);
        }
    }

    /**
     * this method is for getting all of the customer coupons up to a max price
     *
     * @param maxPrice the maximum price of the coupons wanted
     * @return the list of the coupons sorted by the price
     * @throws CouponSystemException <p>1)if there isn't any coupons belong to this customer
     *                               under the maximum price</p>
     *                               <p>2)if something goes wrong in the database</p>
     */
    public List<Coupon> getAllCouponsByMaxPrice(double maxPrice) throws CouponSystemException {
        try {
            List<Coupon> coupons = couponsDAO.getAllCouponsOfCustomerByMaxPrice(customerID, maxPrice);
            if (coupons.size() == 0) {
                throw new CouponSystemException("there isn't any coupons lower then the price: " +
                        maxPrice + " that belongs to this customer");
            }
            coupons.sort(new CouponPriceComparator());
            return coupons;
        } catch (CouponSystemException e) {
            throw new CouponSystemException("getting all coupons failed", e);
        }
    }

    /**
     * this method is used for getting all of the customer details
     * @return an Object of the class Customer
     * @throws CouponSystemException
     * <p>1)if something goes wrong in the database</p>
     */
    public Customer getCustomerDetails() throws CouponSystemException {
        Customer customer = customersDAO.getOneCustomer(customerID);
        List<Coupon> coupons = couponsDAO.getAllCouponsOfCustomer(customerID);
        if(coupons.size() != 0) {
            customer.setCoupons(coupons);
        }
        return customer;
    }
}