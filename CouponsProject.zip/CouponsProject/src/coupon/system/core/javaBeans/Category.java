package coupon.system.core.javaBeans;

public enum Category {
    FOOD,
    ELECTRICITY,
    RESTAURANT,
    VACATION
}
