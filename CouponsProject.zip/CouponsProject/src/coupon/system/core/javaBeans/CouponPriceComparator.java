package coupon.system.core.javaBeans;

import java.util.Comparator;

public class CouponPriceComparator implements Comparator<Coupon> {

    @Override
    public int compare(Coupon o1, Coupon o2) {
        if(o1.getPrice() < o2.getPrice()){
            return -1;
        }else if(o1.getPrice() == o2.getPrice()){
            return 0;
        }else{
            return 1;
        }
    }
}
