package coupon.system.core.coupons_exterminator;

import coupon.system.core.DAOdepartments.CouponsDB_DAO;
import coupon.system.core.exception.CouponSystemException;
import java.time.LocalDate;

public class CouponExpirationDailyJobHelper {
    private static final CouponsDB_DAO couponsDB_dao;

    static {
        couponsDB_dao = new CouponsDB_DAO();
    }

    /**
     * this method is used to delete all of the coupons before today, using the coupons facade
     */
    static void deleteCouponsBeforeToday() {
        LocalDate today = LocalDate.now();
        try {
            couponsDB_dao.deleteAllCouponPurchasesWithEndDateBefore(today);
            couponsDB_dao.deleteAllCouponsWithEndDateBefore(today);
            System.out.println("~*~*~*~*~*~*~*expiration date coupons has been deleted*~*~*~*~*~*~*~*~");
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
    }
}
